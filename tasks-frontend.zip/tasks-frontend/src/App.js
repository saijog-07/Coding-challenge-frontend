import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
import Register from './pages/Register';
import Login from './pages/Login';
import AllTasks from './pages/AllTasks';
import TaskDetail from './pages/TaskDetail';
import AddTask from './pages/AddTask';
import UpdateTask from './pages/UpdateTask';
import './App.css'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/gettasks" element={<AllTasks />} />
        <Route path="/tasks/:taskId" element={<TaskDetail />} />
        <Route path="/addtask" element={<AddTask />} />
        <Route path="/update/:taskId" element={<UpdateTask />} />
      </Routes>
    </Router>
  );
}

export default App;
