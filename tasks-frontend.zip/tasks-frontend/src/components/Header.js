import React from 'react';
import { useLocation, Link } from 'react-router-dom';
import './Header.css';

function Header() {
  const location = useLocation();

  return (
    <header className="header">
      <div className="header-container">
        <div className="header-title">Task Management System</div>

        <nav className="nav-buttons">
          {location.pathname === '/' && (
            <>
              <Link to="/register" className="nav-button">Register</Link>
              <Link to="/login" className="nav-button">Login</Link>
            </>
          )}

          {location.pathname === '/gettasks' && (
            <Link to="/addtask" className="nav-button">Add Task</Link>
          )}
        </nav>
      </div>
    </header>
  );
}

export default Header;
