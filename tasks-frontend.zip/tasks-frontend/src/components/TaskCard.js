import React from 'react';
import { useNavigate } from 'react-router-dom';
import './TaskCard.css';

function TaskCard({ task }) {
  const navigate = useNavigate();

  return (
    <div className="task-card">
      <div className="task-card-body">
        <h3 className="task-title">{task.title}</h3>
        <p className="task-date">Due: {task.dueDate}</p>
        <p className="task-desc">{task.description}</p>
        <p><strong>Priority:</strong> {task.priority}</p>
        <p><strong>Status:</strong> {task.status}</p>
      </div>
      <div className="task-card-footer">
        <button className="view-btn" onClick={() => navigate(`/tasks/${task.taskId}`)}>
          View
        </button>
      </div>
    </div>
  );
}

export default TaskCard;
