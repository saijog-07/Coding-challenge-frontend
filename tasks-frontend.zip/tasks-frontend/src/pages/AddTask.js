import React, { useState } from 'react';
import { Container, Form, Button } from 'semantic-ui-react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import Header from '../components/Header';
import './AddTask.css';

function AddTask() {
  const [form, setForm] = useState({
    taskId: '',
    title: '',
    description: '',
    dueDate: '',
    priority: 'LOW',
    status: 'PENDING'
  });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const validate = () => {
    const { taskId, title, description, dueDate, priority, status } = form;

    if (!taskId || !title || !description || !dueDate || !priority || !status) {
      return 'All fields are required';
    }

    if (!/^\d{6}$/.test(taskId)) {
      return 'Task ID must be exactly 6 digits';
    }

    return null;
  };

  const submit = () => {
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    api.post('/tasks', form)
      .then(() => navigate('/gettasks'))
      .catch(() => setError('Add task failed'));
  };

  return (
    <>
      <Header />
      <Container className="add-task-container">
        <h2>Add Task</h2>
        {error && <div className="error-message">{error}</div>}
        <Form className="add-task-form" onSubmit={e => { e.preventDefault(); submit(); }}>
          <Form.Field>
            <label>Task ID</label>
            <input
              value={form.taskId}
              onChange={e => setForm({ ...form, taskId: e.target.value })}
              placeholder="Enter 6-digit Task ID"
            />
          </Form.Field>

          <Form.Field>
            <label>Title</label>
            <input
              value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
              placeholder="Enter Task Title"
            />
          </Form.Field>

          <Form.Field>
            <label>Description</label>
            <textarea
              value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })}
              placeholder="Enter Task Description"
            />
          </Form.Field>

          <Form.Field>
            <label>Due Date</label>
            <input
              type="date"
              value={form.dueDate}
              onChange={e => setForm({ ...form, dueDate: e.target.value })}
            />
          </Form.Field>

          <Form.Field>
            <label>Priority</label>
            <select
              value={form.priority}
              onChange={e => setForm({ ...form, priority: e.target.value })}
            >
              <option value="LOW">Low</option>
              <option value="MEDIUM">Medium</option>
              <option value="HIGH">High</option>
            </select>
          </Form.Field>

          <Form.Field>
            <label>Status</label>
            <select
              value={form.status}
              onChange={e => setForm({ ...form, status: e.target.value })}
            >
              <option value="PENDING">Pending</option>
              <option value="IN_PROGRESS">In Progress</option>
              <option value="COMPLETED">Completed</option>
            </select>
          </Form.Field>

          <Button type="submit">Add</Button>
        </Form>
      </Container>
    </>
  );
}

export default AddTask;
