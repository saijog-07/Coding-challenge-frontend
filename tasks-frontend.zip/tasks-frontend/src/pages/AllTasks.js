import React, { useState, useEffect } from 'react';
import { Container, Card, Message } from 'semantic-ui-react';
import TaskCard from '../components/TaskCard';
import api from '../services/api';
import Header from '../components/Header';

function AllTasks() {
  const [tasks, setTasks] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/tasks')
      .then(res => setTasks(res.data))
      .catch(() => setError('Failed to load tasks'));
  }, []);

  return (
    <>
      <Header />
      <Container style={{ marginTop: '2em' }}>
        <h2>All Tasks</h2>
        {error && <Message error content={error} />}
        <Card.Group>
          {tasks.map(task => <TaskCard key={task.taskId} task={task} />)}
        </Card.Group>
      </Container>
    </>
  );
}

export default AllTasks;
