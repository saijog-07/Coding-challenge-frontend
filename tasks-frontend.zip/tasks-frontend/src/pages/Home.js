import React from 'react';
import Header from '../components/Header';
import './Home.css';

function Home() {
  return (
    <>
      <Header />
      <div className="home-container">
        <h1 className="home-title">Welcome to Task Management System</h1>
        <p className="home-subtitle">
          Manage your tasks efficiently — add, view, update, and delete tasks.
        </p>
      </div>
    </>
  );
}

export default Home;
