import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import Header from '../components/Header';
import './Login.css';

function Login() {
  const [form, setForm] = useState({ username: '', password: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const validate = () => {
    if (!form.username || !form.password) {
      return 'Both username and password are required';
    }
    return null;
  };

  const submit = async () => {
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    try {
      const res = await api.post('/auth/login', form);
      localStorage.setItem('jwt', res.data);
      navigate('/gettasks');
    } catch (e) {
      setError(e.response?.data || 'Login failed');
    }
  };

  return (
    <>
      <Header />
      <div className="login-container">
        <h2>Login</h2>
        {error && <div className="error-message">{error}</div>}
        <form className="login-form" onSubmit={e => { e.preventDefault(); submit(); }}>
          <label>Username</label>
          <input
            type="text"
            value={form.username}
            onChange={e => setForm({ ...form, username: e.target.value })}
            required
          />

          <label>Password</label>
          <input
            type="password"
            value={form.password}
            onChange={e => setForm({ ...form, password: e.target.value })}
            required
          />

          <button type="submit">Login</button>
        </form>
      </div>
    </>
  );
}

export default Login;
