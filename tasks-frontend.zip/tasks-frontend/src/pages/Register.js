import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';
import Header from '../components/Header';
import './Register.css';

function Register() {
  const [form, setForm] = useState({ username: '', password: '', email: '' });
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const validate = () => {
    const { username, email, password } = form;

    if (!username || !email || !password) {
      return 'All fields are required';
    }

    if (password.length < 8) {
      return 'Password must be at least 8 characters long';
    }

    return null;
  };

  const submit = async () => {
    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    try {
      await api.post('/auth/register', form);
      navigate('/login');
    } catch (e) {
      setError(e.response?.data || 'Registration failed');
    }
  };

  return (
    <>
      <Header />
      <div className="register-container">
        <h2>Register</h2>
        {error && <div className="error-message">{error}</div>}
        <form className="register-form" onSubmit={e => { e.preventDefault(); submit(); }}>
          <label>Username</label>
          <input
            type="text"
            value={form.username}
            onChange={e => setForm({ ...form, username: e.target.value })}
            required
          />

          <label>Email</label>
          <input
            type="email"
            value={form.email}
            onChange={e => setForm({ ...form, email: e.target.value })}
            required
          />

          <label>Password</label>
          <input
            type="password"
            value={form.password}
            onChange={e => setForm({ ...form, password: e.target.value })}
            required
          />

          <button type="submit">Register</button>
        </form>
      </div>
    </>
  );
}

export default Register;
