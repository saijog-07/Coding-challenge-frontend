import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';
import Header from '../components/Header';
import './TaskDetail.css';

function TaskDetail() {
  const { taskId } = useParams();
  const navigate = useNavigate();
  const [task, setTask] = useState(null);
  const [error, setError] = useState('');
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    api.get(`/tasks/${taskId}`)
      .then(res => setTask(res.data))
      .catch(() => setError('Failed to load task'));
  }, [taskId]);

  const deleteTask = () => {
    api.delete(`/tasks/${taskId}`)
      .then(() => navigate('/gettasks'))
      .catch(() => setError('Delete failed'));
  };

  if (!task) {
    return (
      <>
        <Header />
        <div className="task-detail-container">
          {error ? <div className="error-message">{error}</div> : <p>Loading...</p>}
        </div>
      </>
    );
  }

  return (
    <>
      <Header />
      <div className="task-detail-container">
        {error && <div className="error-message">{error}</div>}

        <h2>{task.title}</h2>
        <p><strong>Description:</strong> {task.description}</p>
        <p><strong>Due Date:</strong> {task.dueDate}</p>
        <p><strong>Priority:</strong> {task.priority}</p>
        <p><strong>Status:</strong> {task.status}</p>

        <div className="button-group">
          <button className="delete-btn" onClick={() => setConfirmDelete(true)}>Delete</button>
          <button className="update-btn" onClick={() => navigate(`/update/${task.taskId}`)}>Update</button>
        </div>

        {confirmDelete && (
          <div className="confirm-box">
            <p>Are you sure you want to delete this task?</p>
            <div className="confirm-actions">
              <button onClick={() => setConfirmDelete(false)}>Cancel</button>
              <button onClick={deleteTask}>Confirm</button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default TaskDetail;
