import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../services/api';
import Header from '../components/Header';
import './UpdateTask.css';

function UpdateTask() {
  const { taskId } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    title: '',
    description: '',
    dueDate: '',
    priority: 'LOW',
    status: 'PENDING',
  });
  const [error, setError] = useState('');
  const [confirm, setConfirm] = useState(false);

  useEffect(() => {
    api.get(`/tasks/${taskId}`)
      .then(res => setForm(res.data))
      .catch(() => setError('Load failed'));
  }, [taskId]);

  const submit = () => {
    api.put(`/tasks/${taskId}`, form)
      .then(() => navigate(`/tasks/${taskId}`))
      .catch(() => setError('Update failed'));
  };

  return (
    <>
      <Header />
      <div className="update-task-container">
        <h2>Update Task</h2>
        {error && <div className="error-message">{error}</div>}

        <form className="update-task-form" onSubmit={(e) => { e.preventDefault(); setConfirm(true); }}>
          <label>Title</label>
          <input
            type="text"
            value={form.title}
            onChange={e => setForm({ ...form, title: e.target.value })}
            required
          />

          <label>Description</label>
          <textarea
            value={form.description}
            onChange={e => setForm({ ...form, description: e.target.value })}
            required
          />

          <label>Due Date</label>
          <input
            type="date"
            value={form.dueDate}
            onChange={e => setForm({ ...form, dueDate: e.target.value })}
            required
          />

          <label>Priority</label>
          <select
            value={form.priority}
            onChange={e => setForm({ ...form, priority: e.target.value })}
          >
            <option value="LOW">Low</option>
            <option value="MEDIUM">Medium</option>
            <option value="HIGH">High</option>
          </select>

          <label>Status</label>
          <select
            value={form.status}
            onChange={e => setForm({ ...form, status: e.target.value })}
          >
            <option value="PENDING">Pending</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="COMPLETED">Completed</option>
          </select>

          <button type="submit" className="update-btn">Update</button>
        </form>

        {confirm && (
          <div className="confirm-box">
            <p>Are you sure you want to update this task?</p>
            <div className="confirm-actions">
              <button onClick={() => setConfirm(false)}>Cancel</button>
              <button onClick={submit}>Confirm</button>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default UpdateTask;
